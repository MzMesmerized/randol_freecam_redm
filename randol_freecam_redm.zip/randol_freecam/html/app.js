// Cinematic Camera menu — render only. All input is handled in Lua (cl_menu.lua),
// so this page never takes NUI focus and the free cam keeps mouse look + WASD.
(() => {
    const menuEl = document.getElementById('menu');
    const titleEl = document.getElementById('title');
    const listEl = document.getElementById('list');
    const descEl = document.getElementById('desc');
    const counterEl = document.getElementById('counter');
    const sectionEl = document.getElementById('section');

    const el = (tag, cls, text) => {
        const node = document.createElement(tag);
        if (cls) node.className = cls;
        if (text !== undefined) node.textContent = text;
        return node;
    };

    function buildRow(item, isSelected) {
        const row = el('li', 'row' + (isSelected ? ' is-selected' : ''));
        row.appendChild(el('span', 'row__label', item.label));

        if (item.type === 'list') {
            const wrap = el('span', 'row__value');
            wrap.appendChild(el('span', 'row__arrow', '‹'));
            wrap.appendChild(el('span', 'row__value-text', item.value));
            wrap.appendChild(el('span', 'row__arrow', '›'));
            wrap.appendChild(el('span', 'row__count', `${item.index}/${item.count}`));
            row.appendChild(wrap);
        } else if (item.type === 'check') {
            row.appendChild(el('span', 'row__check' + (item.checked ? ' is-on' : '')));
        }
        return row;
    }

    function render(data) {
        if (data.title) titleEl.textContent = data.title;
        if (data.subtitle !== undefined) sectionEl.textContent = data.subtitle || 'Options';

        const items = data.items || [];
        const selected = Math.max(0, Math.min((data.selected || 1) - 1, items.length - 1));

        listEl.replaceChildren(...items.map((item, i) => buildRow(item, i === selected)));
        counterEl.textContent = `${items.length ? selected + 1 : 0} / ${items.length}`;
        descEl.textContent = (items[selected] && items[selected].description) || '';

        const selRow = listEl.children[selected];
        if (selRow) selRow.scrollIntoView({ block: 'nearest' });
    }

    window.addEventListener('message', (event) => {
        const data = event.data || {};
        switch (data.action) {
            case 'open':
                render(data);
                menuEl.classList.add('is-open');
                menuEl.setAttribute('aria-hidden', 'false');
                break;
            case 'update':
                render(data);
                break;
            case 'close':
                menuEl.classList.remove('is-open');
                menuEl.setAttribute('aria-hidden', 'true');
                break;
        }
    });
})();
