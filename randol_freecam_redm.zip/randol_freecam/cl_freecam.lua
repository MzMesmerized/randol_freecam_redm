--[[
    Randolio: Free Cam - RedM / VORP port
    Requires: ox_lib (3.27.x with RedM support)
]]

local Config = lib.load('config')
local Keys = Config.Keys

local FREE_CAM
local offsetRotX, offsetRotY, offsetRotZ = 0.0, 0.0, 0.0
local precision = 1.0
local speed = 1.0
local camActive = false

local currFilter = 1
local activeFx -- name of the ANIMPOSTFX currently playing, if any

local dofOn = false
local nearIndex = Config.DefaultNearIndex
local farIndex = Config.DefaultFarIndex
local falloffIndex = Config.DefaultFalloffIndex

local barsOn = false
local hudHidden = false

local mapShown = false      -- minimap visibility while the camera is active
local radarWasVisible = nil -- radar state before the camera started, restored on exit

---------------------------------------------------------------------------
-- Helpers
---------------------------------------------------------------------------

local function notify(msg, nType)
    if Config.Notify then Config.Notify(msg, nType) end
end

local function clamp(val, lower, upper)
    if val < lower then return lower end
    if val > upper then return upper end
    return val
end

local function dofValue(list, index)
    return tonumber(list[index]) or 0.0
end

local function applyDof()
    if not dofOn then return end
    local near = dofValue(Config.NearDof, nearIndex)
    local far = dofValue(Config.FarDof, farIndex)
    local falloff = dofValue(Config.FalloffDof, falloffIndex)
    if far <= near then far = near + 1.0 end

    -- SET_HIDOF_OVERRIDE(active, p1, nearPlaneOut, nearPlaneIn, farPlaneOut, farPlaneIn)
    SetHidofOverride(true, false, math.max(near - falloff, 0.0), near, far + falloff, far)
end

local function clearDof()
    SetHidofOverride(false, false, 0.0, 0.0, 0.0, 0.0)
end

local function stopFilter()
    if activeFx then
        AnimpostfxStop(activeFx)
        activeFx = nil
    end
end

-- Failsafe: clears the filter as soon as the menu is no longer open,
-- however it was closed (Escape, Backspace, Enter, another script, death, distance).
local filterWatchdog = false

local function startFilterWatchdog()
    if filterWatchdog then return end
    filterWatchdog = true

    CreateThread(function()
        while activeFx do
            if not FreecamMenu.isOpen() then
                stopFilter()
                currFilter = 1
                break
            end
            Wait(100)
        end
        filterWatchdog = false
    end)
end

local function setFilter(index)
    stopFilter()
    currFilter = index
    local name = Config.Filters[index]
    if name and name ~= 'None' then
        AnimpostfxPlay(name)
        activeFx = name
        startFilterWatchdog()
    end
end

local function toggleMap()
    if camActive then
        -- While the free cam runs the radar is hidden by default (it renders as a black box
        -- under a scripted camera). The menu toggle can still bring it back.
        mapShown = not mapShown
        DisplayRadar(mapShown)
    else
        DisplayRadar(IsRadarHidden())
    end
end

local function toggleBars()
    barsOn = not barsOn
    if not barsOn then return end

    CreateThread(function()
        while barsOn do
            DrawRect(0.5, 0.0, 1.0, 0.23, 0, 0, 0, 255, false, false)
            DrawRect(0.5, 1.0, 1.0, 0.23, 0, 0, 0, 255, false, false)
            Wait(0)
        end
    end)
end

local function toggleHud()
    hudHidden = not hudHidden
    if not hudHidden then return end

    CreateThread(function()
        while hudHidden do
            HideHudAndRadarThisFrame()
            Wait(0)
        end
    end)
end

local function toggleDof()
    dofOn = not dofOn
    if dofOn then
        applyDof()
    else
        clearDof()
    end
end

local function resetEverything()
    ClearFocus()
    clearDof()
    stopFilter()
    RenderScriptCams(false, false, 0, true, false, 0)
    if FREE_CAM and DoesCamExist(FREE_CAM) then
        DestroyCam(FREE_CAM, false)
    end
    FREE_CAM = nil
    camActive = false

    if radarWasVisible ~= nil then
        DisplayRadar(radarWasVisible)
        radarWasVisible = nil
    end
    mapShown = false

    offsetRotX, offsetRotY, offsetRotZ = 0.0, 0.0, 0.0
    speed = 1.0
    precision = 1.0
    currFilter = 1
    dofOn = false
    nearIndex = Config.DefaultNearIndex
    farIndex = Config.DefaultFarIndex
    falloffIndex = Config.DefaultFalloffIndex
    barsOn = false
    hudHidden = false
end

local function setNewFov(change)
    if FREE_CAM and DoesCamExist(FREE_CAM) then
        local newFov = GetCamFov(FREE_CAM) + change
        if newFov >= Config.MinFov and newFov <= Config.MaxFov then
            SetCamFov(FREE_CAM, newFov)
        end
    end
end

---------------------------------------------------------------------------
-- Camera movement
---------------------------------------------------------------------------

local function pressed(key)
    return IsDisabledControlPressed(0, key)
end

local function processNewPos(x, y, z)
    local newPos = { x = x, y = y, z = z }
    local moveSpeed = 0.1 * speed

    local headingRad = math.rad(offsetRotZ)
    local sideRad = math.rad(offsetRotZ + 90.0)

    local function move(rad, direction)
        newPos.x = newPos.x + direction * moveSpeed * math.sin(rad)
        newPos.y = newPos.y - direction * moveSpeed * math.cos(rad)
    end

    if pressed(Keys.Forward) then
        move(headingRad, -1)
    elseif pressed(Keys.Backward) then
        move(headingRad, 1)
    end

    if pressed(Keys.Left) then
        move(sideRad, -1)
    elseif pressed(Keys.Right) then
        move(sideRad, 1)
    end

    if pressed(Keys.Up) then
        newPos.z += moveSpeed
    elseif pressed(Keys.Down) or (Keys.DownAlt and pressed(Keys.DownAlt)) then
        newPos.z -= moveSpeed
    end

    if pressed(Keys.SpeedMod) then
        if pressed(Keys.ScrollUp) then
            speed = math.min(speed + 0.1, Config.MaxSpeed)
        elseif pressed(Keys.ScrollDown) then
            speed = math.max(speed - 0.1, Config.MinSpeed)
        end
    else
        if pressed(Keys.ScrollUp) then
            setNewFov(-1.0) -- zoom in
        elseif pressed(Keys.ScrollDown) then
            setNewFov(1.0)  -- zoom out
        end
    end

    offsetRotX = offsetRotX - (GetDisabledControlNormal(0, Keys.LookUD) * precision * 8.0)
    offsetRotZ = offsetRotZ - (GetDisabledControlNormal(0, Keys.LookLR) * precision * 8.0)

    if pressed(Keys.RollLeft) then
        offsetRotY = offsetRotY - precision
    elseif pressed(Keys.RollRight) then
        offsetRotY = offsetRotY + precision
    end

    offsetRotX = clamp(offsetRotX, -90.0, 90.0)
    offsetRotY = clamp(offsetRotY, -90.0, 90.0)
    offsetRotZ = offsetRotZ % 360.0

    return newPos
end

local function disableControls()
    DisableAllControlActions(0)
    for i = 1, #Config.AllowedControls do
        EnableControlAction(0, Config.AllowedControls[i], true)
    end
end

local EXIT_KEYS = {
    0x156F7119, -- Backspace / Esc  INPUT_FRONTEND_CANCEL
    0x4A903C11, -- Esc              INPUT_FRONTEND_PAUSE_ALTERNATE
}

local function processCamControls()
    disableControls()
    DisableOnFootFirstPersonViewThisUpdate()

    -- Safety exit: if the camera is ever running without the menu open,
    -- Backspace or Esc still gets the player out.
    if not FreecamMenu.isOpen() then
        for i = 1, #EXIT_KEYS do
            if IsDisabledControlJustPressed(0, EXIT_KEYS[i]) then
                camActive = false
                return
            end
        end
    end

    -- Keep the radar off every frame; VORP/HUD scripts may switch it back on.
    if not mapShown then
        DisplayRadar(false)
    end

    local ped = cache.ped
    if IsEntityDead(ped) or IsPedDeadOrDying(ped, true) then
        camActive = false
        FreecamMenu.close('forced')
        return
    end

    local camCoords = GetCamCoord(FREE_CAM)
    local newPos = processNewPos(camCoords.x, camCoords.y, camCoords.z)

    SetFocusPosAndVel(newPos.x, newPos.y, newPos.z, 0.0, 0.0, 0.0)
    SetCamCoord(FREE_CAM, newPos.x, newPos.y, newPos.z)
    SetCamRot(FREE_CAM, offsetRotX, offsetRotY, offsetRotZ, 2)

    if #(GetEntityCoords(ped) - vec3(newPos.x, newPos.y, newPos.z)) > Config.MaxDistance then
        notify('You went too far using the free camera.', 'error')
        camActive = false
        FreecamMenu.close('forced')
    end
end

local function toggleCam()
    camActive = not camActive
    if not camActive then return end

    ClearFocus()

    radarWasVisible = not IsRadarHidden()
    mapShown = false
    DisplayRadar(false)

    local startPos = GetGameplayCamCoord()
    local startRot = GetGameplayCamRot(2)
    offsetRotX, offsetRotY, offsetRotZ = startRot.x, 0.0, startRot.z

    FREE_CAM = CreateCamWithParams('DEFAULT_SCRIPTED_CAMERA',
        startPos.x, startPos.y, startPos.z,
        offsetRotX, offsetRotY, offsetRotZ,
        GetGameplayCamFov() * 1.0, false, 2)

    SetCamActive(FREE_CAM, true)
    RenderScriptCams(true, false, 0, true, false, 0)

    CreateThread(function()
        while camActive do
            processCamControls()
            Wait(0)
        end
        resetEverything()
    end)
end

---------------------------------------------------------------------------
-- Menu
---------------------------------------------------------------------------

-- Friendly names for the filter list (the config keeps the real effect names).
local FILTER_NAMES = {
    None = 'None',
    MP_LobbyBW01 = 'Black & White',
    DEADEYE = 'Dead Eye',
    PlayerDrunk01 = 'Drunk',
    PlayerHealthPoor = 'Wounded',
}

local function filterLabel(name)
    if FILTER_NAMES[name] then return FILTER_NAMES[name] end
    local set, num = name:match('^PhotoMode_Filter(%a+)(%d+)$')
    if set then return ('%s %s'):format(set, num) end
    return name
end

local filterLabels = {}
for i, name in ipairs(Config.Filters) do filterLabels[i] = filterLabel(name) end

local function metres(list)
    local out = {}
    for i, v in ipairs(list) do out[i] = v .. ' m' end
    return out
end

local nearLabels, farLabels, falloffLabels = metres(Config.NearDof), metres(Config.FarDof), metres(Config.FalloffDof)
local FILTER_ROW = 2

local function openMenu()
    if FreecamMenu.isOpen() then
        FreecamMenu.close('cancel')
        return
    end

    FreecamMenu.open({
        title = 'Cinematic Camera',
        subtitle = 'Camera Options',
        onClose = function()
            -- Failsafe: closing the menu, however it happens, always removes the filter.
            stopFilter()
            currFilter = 1

            -- Backing out of the menu also exits the free cam. Leaving the camera running
            -- with no menu kept every control disabled and left the player stuck.
            if camActive then
                camActive = false -- camera loop ends and resetEverything() restores the gameplay cam
            end
        end,
        onSideScroll = function(selected, scrollIndex, args)
            local action = args and args.action
            if action == 'filter' then
                setFilter(scrollIndex)
            elseif action == 'dofNear' then
                nearIndex = scrollIndex
                applyDof()
            elseif action == 'dofFar' then
                farIndex = scrollIndex
                applyDof()
            elseif action == 'dofFalloff' then
                falloffIndex = scrollIndex
                applyDof()
            end
        end,
        onCheck = function(selected, checked, args)
            local action = args and args.action
            if action == 'camera' then
                toggleCam()
            elseif action == 'dof' then
                toggleDof()
            elseif action == 'bars' then
                toggleBars()
            elseif action == 'map' then
                toggleMap()
            elseif action == 'hud' then
                toggleHud()
            end
        end,
        onConfirm = function(selected, scrollIndex, args)
            if args and args.action == 'filter' then
                setFilter(1)
                FreecamMenu.setIndex(FILTER_ROW, 1)
            end
        end,
        options = {
            { label = 'Toggle Camera', checked = camActive, args = { action = 'camera' },
              description = 'Detach the camera and fly it with WASD, Space and Ctrl or Z.' },
            { label = 'Camera Filter', values = Config.Filters, valueLabels = filterLabels, defaultIndex = currFilter, args = { action = 'filter' },
              description = 'Left and right to browse filters. Enter resets to none.' },
            { label = 'Depth of Field', checked = dofOn, args = { action = 'dof' }, description = 'Blur what sits outside the focus range.' },
            { label = 'Black Bars', checked = barsOn, args = { action = 'bars' }, description = 'Letterbox the frame like a picture show.' },
            { label = 'Minimap', checked = (camActive and mapShown) or (not camActive and not IsRadarHidden()), args = { action = 'map' },
              description = 'Show or hide the minimap.' },
            { label = 'Hide HUD', checked = hudHidden, args = { action = 'hud' }, description = 'Hide the HUD and minimap for clean shots.' },
            { label = 'Focus Near', values = Config.NearDof, valueLabels = nearLabels, defaultIndex = nearIndex, args = { action = 'dofNear' },
              description = 'Distance where the sharp zone starts.' },
            { label = 'Focus Far', values = Config.FarDof, valueLabels = farLabels, defaultIndex = farIndex, args = { action = 'dofFar' },
              description = 'Distance where the sharp zone ends.' },
            { label = 'Focus Falloff', values = Config.FalloffDof, valueLabels = falloffLabels, defaultIndex = falloffIndex, args = { action = 'dofFalloff' },
              description = 'How quickly things blur outside the sharp zone. Lower is stronger.' },
        },
    })
end

RegisterCommand(Config.CommandName, openMenu, false)

---------------------------------------------------------------------------
-- Cleanup
---------------------------------------------------------------------------

AddEventHandler('onResourceStop', function(resource)
    if resource ~= cache.resource then return end
    if camActive or FREE_CAM then
        FreecamMenu.close('forced')
        resetEverything()
    end
end)
