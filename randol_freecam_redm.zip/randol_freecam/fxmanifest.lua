fx_version 'cerulean'
game 'rdr3'
rdr3_warning 'I acknowledge that this is a prerelease build of RedM, and I am aware my resources *will* become incompatible once RedM ships.'

author 'Randolio (RedM / VORP port)'
description 'Free Cam - RedM port with a red & black menu'
version '1.1.0-redm'

lua54 'yes'

dependency 'ox_lib'

shared_scripts {
    '@ox_lib/init.lua',
}

client_scripts {
    'cl_menu.lua',     -- red & black menu (must load before cl_freecam.lua)
    'cl_freecam.lua',
}

ui_page 'html/index.html'

-- config.lua is read with lib.load(), so it only needs to be streamed to the client,
-- not executed as a client script.
files {
    'config.lua',
    'html/index.html',
    'html/style.css',
    'html/app.js',
    'html/fonts/*.woff2',
}
