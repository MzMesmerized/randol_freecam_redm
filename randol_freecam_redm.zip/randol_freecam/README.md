# Randolio: Free Cam — RedM / VORP port

Cinematic free camera with a red & black frontier menu, ported from the FiveM original to RedM.

Original resource by Randolio, based on Kiminaze's cinematiccam (https://github.com/Kiminaze/cinematiccam/tree/master).

## Requirements
- RedM server (VORP or any framework; the script has no framework calls)
- ox_lib 3.27.x with RedM support, started **before** this resource (used for config loading, cache and notifications)

## Install
1. Drop the `randol_freecam` folder into your resources.
2. In `server.cfg`, after `ensure ox_lib`: `ensure randol_freecam`
3. In-game: `/ccam`

## Controls (camera active)
| Action | Key |
|---|---|
| Move | W / A / S / D |
| Up / Down | Space / Left Ctrl or Z |
| Look | Mouse |
| Roll | Q / E |
| Zoom (FOV) | Mouse wheel |
| Move speed | Hold Shift + mouse wheel |

All keys are RDR3 control hashes in `config.lua` → `Keys`.

## Menu
Freecam has its own red & black menu (`cl_menu.lua` + `html/`) instead of ox_lib's list menu, so the rest of your ox_lib menus are untouched.

| Key | Menu action |
|---|---|
| Arrow Up / Down | Move selection (hold to repeat) |
| Arrow Left / Right | Change a value (filter, focus distances) |
| Enter | Toggle a checkbox; on Camera Filter, reset to None |
| Backspace / Esc | Close the menu and exit the free cam (controls return to normal) |

Options: Toggle Camera · Camera Filter · Depth of Field · Black Bars · Minimap · Hide HUD · Focus Near / Far / Falloff

The menu never takes keyboard or mouse focus. Keys are read as RDR3 frontend controls in Lua, so mouse look and WASD keep working while it's open.
Closing the menu in any way (Backspace, Esc, `/ccam`, death, going too far) always removes the active filter and exits the free cam. If the camera is ever running without the menu, Backspace or Esc still exits it.

Fonts: Rye and Crimson Text, both SIL Open Font License 1.1 (licences in `html/fonts/`).

## Changes from the FiveM version
- **Manifest:** `game 'rdr3'` plus the required `rdr3_warning`; config is loaded through `files` + `lib.load`.
- **Controls:** all GTA control IDs replaced with RDR3 hashes. All game controls are disabled while the camera is active, so the ped can't walk, shoot, whistle or use Dead Eye, on foot or mounted. Add exceptions in `AllowedControls`.
- **Filters:** GTA timecycle names don't exist in RDR3. They are replaced with RDR3's ANIMPOSTFX set, the same Photo Mode filters (Game / Modern / Vintage) plus a few extras.
- **Depth of field:** RDR3 doesn't have GTA's `SetCamNearDof` / `SetCamFarDof` / `SetCamDofStrength` / `SetUseHiDof`. DoF now uses `SET_HIDOF_OVERRIDE` with Near / Far / Falloff distances in metres.
- **Focus:** `SetFocusArea` → `SetFocusPosAndVel`. First-person blocking → `DisableOnFootFirstPersonViewThisUpdate`.
- **Death:** GTA's `CEventNetworkEntityDamage` game event replaced by a per-frame dead/dying check, which works with VORP's death state.
- **Camera start:** spawns at the gameplay camera's position and angle instead of inside the ped.
- **Fixes:** the black bars no longer freeze the menu callback; `math.clamp` no longer depends on ox_lib's math module having been loaded; a stray global `currFov` was removed; cleanup runs on resource stop.
- **Added:** Hide HUD toggle (RDR's HUD cores clutter shots).
- **Notifications:** this ox_lib build sends `lib.notify` to `bln_notify`, so a title is always passed. Swap `Config.Notify` for VORP's `vorp:TipRight` if you don't run bln_notify.
