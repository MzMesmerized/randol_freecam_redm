--[[
    Freecam menu (red & black) — replaces ox_lib's list menu for this resource only.

    Input is read from RDR3 frontend controls in Lua, and the NUI page only draws.
    The page never takes NUI focus, so the free cam keeps full mouse look and movement
    while the menu is open.

    API
      FreecamMenu.open(data)   data = {
          title, subtitle?,
          options = { { label, description?, checked?, values?, valueLabels?, defaultIndex?, args? }, ... },
          onSideScroll(selected, scrollIndex, args),  -- left/right on a values row
          onCheck(selected, checked, args),           -- Enter on a checkbox row
          onConfirm(selected, scrollIndex, args),     -- Enter on any other row
          onClose(reason),                            -- 'cancel' | 'forced' (fires on EVERY close)
      }
      FreecamMenu.close(reason?)
      FreecamMenu.isOpen()
]]

FreecamMenu = {}

local KEY = {
    up       = 0x6319DB71, -- Arrow Up     INPUT_FRONTEND_UP
    down     = 0x05CA7C52, -- Arrow Down   INPUT_FRONTEND_DOWN
    left     = 0xA65EBAB4, -- Arrow Left   INPUT_FRONTEND_LEFT
    right    = 0xDEB34313, -- Arrow Right  INPUT_FRONTEND_RIGHT
    accept   = 0xC7B5340A, -- Enter        INPUT_FRONTEND_ACCEPT
    cancel   = 0x156F7119, -- Backspace/Esc INPUT_FRONTEND_CANCEL
    pauseAlt = 0x4A903C11, -- Esc          INPUT_FRONTEND_PAUSE_ALTERNATE (blocked so Esc doesn't open the pause menu)
}

local function wipe(t)
    for k in pairs(t) do t[k] = nil end
end

local REPEAT_DELAY = 350 -- ms before a held arrow starts repeating
local REPEAT_RATE = 70   -- ms between repeats

local current     -- the open menu's data table
local selected = 1
local indices = {} -- scroll index per values row
local blockPauseUntil = 0

---------------------------------------------------------------------------

local function valueLabel(opt, i)
    if opt.valueLabels and opt.valueLabels[i] then return opt.valueLabels[i] end
    local v = opt.values[i]
    if type(v) == 'table' then return v.label or tostring(v[1]) end
    return tostring(v)
end

local function serialize()
    local items = {}
    for i, opt in ipairs(current.options) do
        local item = { label = opt.label, description = opt.description }
        if opt.values then
            item.type = 'list'
            item.index = indices[i]
            item.count = #opt.values
            item.value = valueLabel(opt, indices[i])
        elseif opt.checked ~= nil then
            item.type = 'check'
            item.checked = opt.checked and true or false
        else
            item.type = 'button'
        end
        items[i] = item
    end
    return items
end

local function push(action)
    SendNUIMessage({
        action = action,
        title = current.title,
        subtitle = current.subtitle,
        items = serialize(),
        selected = selected,
    })
end

-- true on the first press, then again on auto-repeat while held
local held = {}
local function navPressed(key)
    local now = GetGameTimer()
    if IsDisabledControlJustPressed(0, key) then
        held[key] = now + REPEAT_DELAY
        return true
    end
    if held[key] and IsDisabledControlPressed(0, key) then
        if now >= held[key] then
            held[key] = now + REPEAT_RATE
            return true
        end
    else
        held[key] = nil
    end
    return false
end

local function blockMenuKeys()
    for _, key in pairs(KEY) do
        DisableControlAction(0, key, true)
    end
end

---------------------------------------------------------------------------

function FreecamMenu.isOpen()
    return current ~= nil
end

function FreecamMenu.close(reason)
    if not current then return end
    local menu = current
    current = nil
    wipe(held)
    SendNUIMessage({ action = 'close' })

    -- keep Esc from falling through to the pause menu on the frame(s) after closing
    blockPauseUntil = GetGameTimer() + 400
    CreateThread(function()
        while GetGameTimer() < blockPauseUntil do
            DisableControlAction(0, KEY.pauseAlt, true)
            DisableControlAction(0, KEY.cancel, true)
            Wait(0)
        end
    end)

    if menu.onClose then menu.onClose(reason or 'forced') end
end

local function step(delta)
    local count = #current.options
    selected = ((selected - 1 + delta) % count) + 1
    push('update')
end

local function scroll(delta)
    local opt = current.options[selected]
    if not opt or not opt.values then return end
    local count = #opt.values
    indices[selected] = ((indices[selected] - 1 + delta) % count) + 1
    push('update')
    if current.onSideScroll then
        current.onSideScroll(selected, indices[selected], opt.args)
    end
end

local function confirm()
    local opt = current.options[selected]
    if not opt then return end

    if opt.checked ~= nil and not opt.values then
        opt.checked = not opt.checked
        push('update')
        if current.onCheck then current.onCheck(selected, opt.checked, opt.args) end
    elseif current.onConfirm then
        current.onConfirm(selected, indices[selected], opt.args)
        if current then push('update') end
    end
end

function FreecamMenu.open(data)
    if current then FreecamMenu.close('forced') end

    current = data
    selected = 1
    wipe(indices)
    wipe(held)
    for i, opt in ipairs(data.options) do
        if opt.values then
            local idx = opt.defaultIndex or 1
            indices[i] = math.max(1, math.min(idx, #opt.values))
        end
    end

    push('open')

    CreateThread(function()
        local menu = data
        while current == menu do
            blockMenuKeys()

            if navPressed(KEY.up) then
                step(-1)
            elseif navPressed(KEY.down) then
                step(1)
            elseif navPressed(KEY.left) then
                scroll(-1)
            elseif navPressed(KEY.right) then
                scroll(1)
            elseif IsDisabledControlJustPressed(0, KEY.accept) then
                confirm()
            elseif IsDisabledControlJustPressed(0, KEY.cancel) or IsDisabledControlJustPressed(0, KEY.pauseAlt) then
                FreecamMenu.close('cancel')
            end

            Wait(0)
        end
    end)
end

-- Let the main script change a row's value (e.g. when a setting is reset) without reopening.
function FreecamMenu.setIndex(optionIndex, scrollIndex)
    if not current or not current.options[optionIndex] then return end
    indices[optionIndex] = scrollIndex
    push('update')
end

AddEventHandler('onResourceStop', function(resource)
    if resource == GetCurrentResourceName() then
        SendNUIMessage({ action = 'close' })
    end
end)
