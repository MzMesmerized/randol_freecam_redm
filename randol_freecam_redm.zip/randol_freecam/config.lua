return {
    CommandName = 'ccam', -- /ccam
    MaxDistance = 10.0,   -- how far the camera may go from your ped before it shuts off.
    MinSpeed = 0.1,
    MaxSpeed = 10.0,
    MinFov = 1.0,
    MaxFov = 130.0,

    -- Notification wrapper. This ox_lib build routes lib.notify to bln_notify.
    -- Swap for VORP if you prefer, e.g.:
    --   Notify = function(msg) TriggerEvent('vorp:TipRight', msg, 4000) end,
    Notify = function(msg, nType)
        lib.notify({ title = 'Cinematic Camera', description = msg, type = nType or 'inform' })
    end,

    -- RDR3 control hashes (https://github.com/femga/rdr3_discoveries/tree/master/Controls)
    Keys = {
        Forward    = 0x8FD015D8, -- W   INPUT_MOVE_UP_ONLY
        Backward   = 0xD27782E3, -- S   INPUT_MOVE_DOWN_ONLY
        Left       = 0x7065027D, -- A   INPUT_MOVE_LEFT_ONLY
        Right      = 0xB4E465B4, -- D   INPUT_MOVE_RIGHT_ONLY
        Up         = 0xD9D0E1C0, -- Space      INPUT_JUMP
        Down       = 0xDB096B85, -- Left Ctrl  INPUT_DUCK
        DownAlt    = 0x26E9DC00, -- Z          INPUT_GAME_MENU_TAB_LEFT_SECONDARY (also lowers the camera)
        SpeedMod   = 0x8FFC75D6, -- Shift      INPUT_SPRINT (hold + scroll = speed)
        ScrollUp   = 0xCC1075A7, -- Mouse wheel up    INPUT_PREV_WEAPON
        ScrollDown = 0xFD0F0C2C, -- Mouse wheel down  INPUT_NEXT_WEAPON
        RollLeft   = 0xDE794E3E, -- Q   INPUT_COVER
        RollRight  = 0xCEFD9220, -- E   INPUT_ENTER
        LookLR     = 0xA987235F, -- Mouse X  INPUT_LOOK_LR
        LookUD     = 0xD2047988, -- Mouse Y  INPUT_LOOK_UD
    },

    -- While the camera is active ALL game controls are disabled (on foot, mounted, in wagons)
    -- so the ped doesn't move or shoot. Anything listed here is re-enabled.
    -- Keymappings registered by other resources (chat, voice via RegisterKeyMapping, F8) are not game controls and keep working.
    AllowedControls = {
        0x4BC9DABB, -- N  INPUT_PUSH_TO_TALK (native voice)
    },

    -- Depth of field (RDR3 has no GTA-style DoF natives; this uses SET_HIDOF_OVERRIDE).
    -- Distances are in metres from the camera. Everything between Near and Far stays sharp,
    -- and blur reaches full strength Falloff metres beyond each edge (smaller = stronger effect).
    NearDof    = { '0.5', '1.0', '1.5', '2.0', '3.0', '4.0', '5.0', '7.5', '10.0', '15.0' },
    FarDof     = { '2.0', '3.0', '5.0', '7.5', '10.0', '15.0', '20.0', '30.0', '50.0', '75.0', '100.0', '150.0', '200.0' },
    FalloffDof = { '0.5', '1.0', '2.0', '3.0', '5.0', '7.5', '10.0', '15.0', '20.0' },
    DefaultNearIndex    = 2, -- 1.0 m
    DefaultFarIndex     = 7, -- 20.0 m
    DefaultFalloffIndex = 4, -- 3.0 m

    -- RDR3 screen filters (ANIMPOSTFX). The PhotoMode_* set is what the game's own photo mode uses.
    -- List source: https://github.com/femga/rdr3_discoveries/blob/master/graphics/animpostfx/animpostfx.lua
    Filters = {
        'None',
        'PhotoMode_FilterGame01',
        'PhotoMode_FilterGame02',
        'PhotoMode_FilterGame03',
        'PhotoMode_FilterGame04',
        'PhotoMode_FilterGame05',
        'PhotoMode_FilterGame06',
        'PhotoMode_FilterGame07',
        'PhotoMode_FilterGame08',
        'PhotoMode_FilterGame09',
        'PhotoMode_FilterGame10',
        'PhotoMode_FilterGame11',
        'PhotoMode_FilterGame12',
        'PhotoMode_FilterGame13',
        'PhotoMode_FilterGame14',
        'PhotoMode_FilterGame15',
        'PhotoMode_FilterGame16',
        'PhotoMode_FilterGame17',
        'PhotoMode_FilterGame18',
        'PhotoMode_FilterModern01',
        'PhotoMode_FilterModern02',
        'PhotoMode_FilterModern03',
        'PhotoMode_FilterModern04',
        'PhotoMode_FilterModern05',
        'PhotoMode_FilterModern06',
        'PhotoMode_FilterModern07',
        'PhotoMode_FilterModern08',
        'PhotoMode_FilterModern09',
        'PhotoMode_FilterModern10',
        'PhotoMode_FilterVintage01',
        'PhotoMode_FilterVintage02',
        'PhotoMode_FilterVintage03',
        'PhotoMode_FilterVintage04',
        'PhotoMode_FilterVintage05',
        'PhotoMode_FilterVintage06',
        'PhotoMode_FilterVintage07',
        'PhotoMode_FilterVintage08',
        'PhotoMode_FilterVintage09',
        'PhotoMode_FilterVintage10',
        'MP_LobbyBW01',
        'DEADEYE',
        'PlayerDrunk01',
        'PlayerHealthPoor',
    },
}
